import tkinter as tk
from tkinter import messagebox, ttk
import sqlalchemy
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def conectar_bd():
    engine = sqlalchemy.create_engine('mysql+mysqlconnector://root:curso@localhost/ENCUESTAS')
    return engine

def ejecutar_query(query, params=(), fetch=False):
    try:
        engine = conectar_bd()
        with engine.connect() as conn:
            result = conn.execute(sqlalchemy.text(query), params)
            if fetch:
                return result.fetchall()
            else:
                conn.commit()
                return None
    except sqlalchemy.exc.SQLAlchemyError as err:
        messagebox.showerror("Error", f"Error: {err}")
        return None

def agregar_encuesta():
    try:
        params = {
            'idEncuesta': int(entrada_id_encuesta.get()),
            'edad': int(entrada_edad.get()),
            'Sexo': entrada_sexo.get(),
            'BebidasSemana': int(entrada_bebidas_semana.get()),
            'CervezasSemana': int(entrada_cervezas_semana.get()),
            'BebidasFinSemana': int(entrada_bebidas_fin_semana.get()),
            'BebidasDestiladasSemana': int(entrada_bebidas_destiladas_semana.get()),
            'VinosSemana': int(entrada_vinos_semana.get()),
            'PerdidasControl': int(entrada_perdidas_control.get()),
            'DiversionDependenciaAlcohol': entrada_diversion_dependencia_alcohol.get(),
            'ProblemasDigestivos': entrada_problemas_digestivos.get(),
            'TensionAlta': entrada_tension_alta.get(),
            'DolorCabeza': entrada_dolor_cabeza.get()
        }
    except ValueError:
        messagebox.showerror("Error", "Por favor ingrese solo números válidos en los campos numéricos.")
        return
    query = """
    INSERT INTO ENCUESTA (idEncuesta, edad, Sexo, BebidasSemana, CervezasSemana, BebidasFinSemana, BebidasDestiladasSemana, VinosSemana, PerdidasControl, DiversionDependenciaAlcohol, ProblemasDigestivos, TensionAlta, DolorCabeza)
    VALUES (:idEncuesta, :edad, :Sexo, :BebidasSemana, :CervezasSemana, :BebidasFinSemana, :BebidasDestiladasSemana, :VinosSemana, :PerdidasControl, :DiversionDependenciaAlcohol, :ProblemasDigestivos, :TensionAlta, :DolorCabeza)
    """
    if ejecutar_query(query, params) is None:
        messagebox.showinfo("Éxito", "Encuesta agregada exitosamente")
        ver_encuestas()

def actualizar_encuesta():
    try:
        params = {
            'edad': int(entrada_edad.get()),
            'Sexo': entrada_sexo.get(),
            'BebidasSemana': int(entrada_bebidas_semana.get()),
            'CervezasSemana': int(entrada_cervezas_semana.get()),
            'BebidasFinSemana': int(entrada_bebidas_fin_semana.get()),
            'BebidasDestiladasSemana': int(entrada_bebidas_destiladas_semana.get()),
            'VinosSemana': int(entrada_vinos_semana.get()),
            'PerdidasControl': int(entrada_perdidas_control.get()),
            'DiversionDependenciaAlcohol': entrada_diversion_dependencia_alcohol.get(),
            'ProblemasDigestivos': entrada_problemas_digestivos.get(),
            'TensionAlta': entrada_tension_alta.get(),
            'DolorCabeza': entrada_dolor_cabeza.get(),
            'idEncuesta': int(entrada_id_encuesta.get())
        }
    except ValueError:
        messagebox.showerror("Error", "Datos de entrada inválidos")
        return
    query = """
    UPDATE ENCUESTA SET edad = :edad, Sexo = :Sexo, BebidasSemana = :BebidasSemana, CervezasSemana = :CervezasSemana, BebidasFinSemana = :BebidasFinSemana, BebidasDestiladasSemana = :BebidasDestiladasSemana, VinosSemana = :VinosSemana, PerdidasControl = :PerdidasControl, DiversionDependenciaAlcohol = :DiversionDependenciaAlcohol, ProblemasDigestivos = :ProblemasDigestivos, TensionAlta = :TensionAlta, DolorCabeza = :DolorCabeza
    WHERE idEncuesta = :idEncuesta
    """
    if ejecutar_query(query, params) is None:
        messagebox.showinfo("Éxito", "Encuesta actualizada exitosamente")
        ver_encuestas()

def eliminar_encuesta():
    try:
        id_encuesta = int(entrada_id_encuesta.get())
    except ValueError:
        messagebox.showerror("Error", "ID de encuesta inválido")
        return
    query = "DELETE FROM ENCUESTA WHERE idEncuesta = :idEncuesta"
    if ejecutar_query(query, {'idEncuesta': id_encuesta}) is None:
        messagebox.showinfo("Éxito", "Encuesta eliminada exitosamente")
        ver_encuestas()

def ver_encuestas():
    try:
        registros = ejecutar_query("SELECT * FROM ENCUESTA", fetch=True)
        if registros:
            for row in tree.get_children():
                tree.delete(row)
            for registro in registros:
                formatted_data = [str(value).strip(",\"'()") for value in registro]
                tree.insert("", tk.END, values=formatted_data)
    except Exception as e:
        messagebox.showerror("Error", f"Error al ver encuestas: {e}")

def exportar_a_excel():
    try:
        engine = conectar_bd()
        df = pd.read_sql("SELECT * FROM ENCUESTA", engine)
        df.to_excel("encuestas.xlsx", index=False)
        messagebox.showinfo("Éxito", "Datos exportados a encuestas.xlsx exitosamente")
    except Exception as e:
        messagebox.showerror("Error", f"Error al exportar a Excel: {e}")

def graficar_columna():
    try:
        columna = columna_seleccionada.get()
        tipo_grafico = tipo_grafico_seleccionado.get()
        query = f'SELECT `{columna}`, COUNT(*) as count FROM ENCUESTA GROUP BY `{columna}`'
        engine = conectar_bd()
        df = pd.read_sql(query, engine)

        if df.empty:
            messagebox.showerror("Error", f"No hay datos para la columna {columna}")
            return

        new_tab = ttk.Frame(notebook)
        notebook.add(new_tab, text=f"Gráfico {columna}")

        fig, ax = plt.subplots(figsize=(10, 6))
        if tipo_grafico == "Barras":
            ax.bar(df[columna], df['count'], color='skyblue')
        elif tipo_grafico == "Líneas":
            ax.plot(df[columna], df['count'], marker='o', linestyle='-', color='skyblue')
        elif tipo_grafico == "Puntos":
            ax.scatter(df[columna], df['count'], color='skyblue')

        ax.set_xlabel(columna)
        ax.set_ylabel('Cantidad de Encuestas')
        ax.set_title(f'Distribución de {columna}')

        canvas = FigureCanvasTkAgg(fig, master=new_tab)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        ttk.Button(new_tab, text="Cerrar Gráfico", command=lambda: notebook.forget(new_tab)).pack(side=tk.BOTTOM, pady=10)
    except Exception as e:
        messagebox.showerror("Error", f"Error al graficar columna: {e}")

def on_tree_select(event):
    try:
        if tree.selection():
            selected_item = tree.selection()[0]
            values = tree.item(selected_item, 'values')
            for entry, value in zip(entries, values):
                entry.delete(0, tk.END)
                entry.insert(0, value)
    except Exception as e:
        messagebox.showerror("Error", f"Error al seleccionar en el árbol: {e}")

orden_ascendente = {}

def ordenar_por_columna(col):
    try:
        global orden_ascendente, tree
        if col not in orden_ascendente:
            orden_ascendente[col] = True
        datos = [(tree.set(k, col), k) for k in tree.get_children('')]
        try:
            datos.sort(key=lambda t: float(t[0]), reverse=not orden_ascendente[col])
        except ValueError:
            datos.sort(key=lambda t: t[0], reverse=not orden_ascendente[col])
        for index, (val, k) in enumerate(datos):
            tree.move(k, '', index)
        orden_ascendente[col] = not orden_ascendente[col]
    except Exception as e:
        messagebox.showerror("Error", f"Error al ordenar columna: {e}")

def limpiar_encuesta():
    try:
        for entry in entries:
            entry.delete(0, tk.END)
    except Exception as e:
        messagebox.showerror("Error", f"Error al limpiar encuesta: {e}")

def crear_ventana_principal():
    global entrada_edad, entrada_sexo, entrada_bebidas_semana, entrada_cervezas_semana, entrada_bebidas_fin_semana, entrada_bebidas_destiladas_semana, entrada_vinos_semana, entrada_perdidas_control, entrada_diversion_dependencia_alcohol, entrada_problemas_digestivos, entrada_tension_alta, entrada_dolor_cabeza, entrada_id_encuesta, notebook, tree, orden_ascendente, entries, columna_seleccionada, tipo_grafico_seleccionado, result_frame

    orden_ascendente = {}
    root = tk.Tk()
    root.title("Gestión de Encuestas de Salud")
    root.state('zoomed')
    root.configure(bg="#e0f7fa")

    style = ttk.Style()
    style.theme_use('clam')
    style.configure("TButton", background="#00796b", foreground="white", font=("Arial", 10, "bold"))
    style.map("TButton", background=[("active", "#004d40")])
    style.configure("TLabel", background="#e0f7fa", foreground="#004d40", font=("Arial", 10))
    style.configure("TEntry", padding=5)
    style.configure("TFrame", background="#e0f7fa")
    style.configure("TLabelframe", background="#e0f7fa", font=("Arial", 12, "bold"))
    style.configure("TLabelframe.Label", background="#00796b", foreground="white")

    main_frame = ttk.Frame(root, padding="10")
    main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
    root.columnconfigure(0, weight=1)
    root.rowconfigure(0, weight=1)

    notebook = ttk.Notebook(main_frame)
    notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
    main_frame.columnconfigure(0, weight=1)
    main_frame.rowconfigure(0, weight=1)

    input_frame = ttk.Frame(notebook, padding="10")
    notebook.add(input_frame, text="Datos de la Encuesta")
    input_frame.columnconfigure(1, weight=1)
    input_frame.rowconfigure(0, weight=1)

    labels = ["ID Encuesta", "Edad", "Sexo", "Bebidas Semana", "Cervezas Semana", "Bebidas Fin Semana",
        "Bebidas Destiladas Semana", "Vinos Semana", "Perdidas Control", "Diversión Dependencia Alcohol",
        "Problemas Digestivos", "Tensión Alta", "Dolor Cabeza"]
    entries = [ttk.Entry(input_frame) for _ in labels]
    for i, (label, entry) in enumerate(zip(labels, entries)):
        ttk.Label(input_frame, text=label).grid(row=i, column=0, padx=5, pady=5, sticky=tk.W)
        entry.grid(row=i, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

    entrada_id_encuesta, entrada_edad, entrada_sexo, entrada_bebidas_semana, entrada_cervezas_semana, entrada_bebidas_fin_semana, entrada_bebidas_destiladas_semana, entrada_vinos_semana, entrada_perdidas_control, entrada_diversion_dependencia_alcohol, entrada_problemas_digestivos, entrada_tension_alta, entrada_dolor_cabeza = entries

    button_frame = ttk.Frame(input_frame, padding="10")
    button_frame.grid(row=13, column=0, columnspan=2, padx=10, pady=10, sticky=(tk.W, tk.E))
    button_frame.columnconfigure((0, 1, 2), weight=1)

    ttk.Button(button_frame, text="Agregar Encuesta", command=agregar_encuesta).grid(row=0, column=0, padx=10, pady=10,
                                                                                     sticky=(tk.W, tk.E))
    ttk.Button(button_frame, text="Ver Encuestas", command=ver_encuestas).grid(row=0, column=1, padx=10, pady=10,
                                                                               sticky=(tk.W, tk.E))
    ttk.Button(button_frame, text="Actualizar Encuesta", command=actualizar_encuesta).grid(row=1, column=0, padx=10,
                                                                                           pady=10, sticky=(tk.W, tk.E))
    ttk.Button(button_frame, text="Eliminar Encuesta", command=eliminar_encuesta).grid(row=1, column=1, padx=10,
                                                                                       pady=10, sticky=(tk.W, tk.E))
    ttk.Button(button_frame, text="Exportar a Excel", command=exportar_a_excel).grid(row=2, column=0, padx=10, pady=10,
                                                                                     sticky=(tk.W, tk.E))
    ttk.Button(button_frame, text="Limpiar Encuesta", command=limpiar_encuesta).grid(row=2, column=1, padx=10, pady=10,
                                                                                     sticky=(tk.W, tk.E))

    filter_frame = ttk.LabelFrame(input_frame, text="Filtros para Gráficos", padding="10")
    filter_frame.grid(row=14, column=0, columnspan=2, padx=10, pady=10, sticky=(tk.W, tk.E))
    filter_frame.columnconfigure(1, weight=1)

    # Remove "ID Encuesta" from the labels for the filter
    filter_labels = ["Edad", "Sexo", "Bebidas Semana", "Cervezas Semana", "Bebidas Fin Semana",
        "Bebidas Destiladas Semana", "Vinos Semana", "Perdidas Control", "Diversión Dependencia Alcohol",
        "Problemas Digestivos", "Tensión Alta", "Dolor Cabeza"]

    ttk.Label(filter_frame, text="Seleccionar Columna").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    columna_seleccionada = ttk.Combobox(filter_frame, values=filter_labels)
    columna_seleccionada.grid(row=0, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

    ttk.Label(filter_frame, text="Tipo de Gráfico").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
    tipo_grafico_seleccionado = ttk.Combobox(filter_frame, values=["Barras", "Líneas", "Puntos"])
    tipo_grafico_seleccionado.grid(row=1, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))
    tipo_grafico_seleccionado.current(0)

    ttk.Button(filter_frame, text="Gráfico Columna", command=graficar_columna).grid(row=2, column=0, columnspan=2,
                                                                                    padx=10, pady=10,
                                                                                    sticky=(tk.W, tk.E))

    result_frame = ttk.LabelFrame(input_frame, text="Resultados", padding="10")
    result_frame.grid(row=0, column=2, rowspan=15, padx=10, pady=10, sticky=(tk.W, tk.E, tk.N, tk.S))
    result_frame.columnconfigure(0, weight=1)
    result_frame.rowconfigure(0, weight=1)

    columns = ["ID Encuesta", "Edad", "Sexo", "Bebidas Semana", "Cervezas Semana", "Bebidas Fin Semana",
        "Bebidas Destiladas Semana", "Vinos Semana", "Perdidas Control", "Diversión Dependencia Alcohol",
        "Problemas Digestivos", "Tensión Alta", "Dolor Cabeza"]
    tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=5)
    for col in columns:
        tree.heading(col, text=col, command=lambda _col=col: ordenar_por_columna(_col))
        tree.column(col, anchor=tk.CENTER, width=100)
    tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

    scrollbar_y = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=tree.yview)
    tree.configure(yscroll=scrollbar_y.set)
    scrollbar_y.grid(row=0, column=1, sticky=(tk.N, tk.S))

    tree.bind("<<TreeviewSelect>>", on_tree_select)

    root.mainloop()

crear_ventana_principal()